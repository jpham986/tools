SB-Assembler V3

This zip file contains the SB-Assembler.
Please visit www.sbprojects.net/sbasm for a detailed description.

The SB-Assembler can be used on Linux, Mac and Windows machines.
It requires at least Python 3.2 to be installed.
Installation of the software is not necessary. Unzip everything
into a directory of your choice and make sure the program sbasm
(for Linux and Mac) or sbasm.py (for Windows) is in your path.
However you may want to move the opcode test files and header
files somewhere else.
The only thing that is important for the SB-Assembler is that the
sbapack directory remains in the same directory as the sbasm and
sbasm.py files.

Happy coding.
